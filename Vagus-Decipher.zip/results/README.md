# Vagus-Decipher Results Directory

This directory stores simulation outputs, analysis results, and benchmark reports.

## Output Structure

```

results/
├── benchmarks/          # Benchmark results (M1, M2, M3)
├── figures/             # Generated figures and plots
├── logs/                # Processing logs
└── reports/             # JSON/CSV result files

```

## File Formats

- **JSON (.json)**: Structured result data
- **CSV (.csv)**: Time series data
- **PNG/PDF (.png, .pdf)**: Visualization outputs
- **NPZ (.npz)**: Compressed numpy arrays

## Example Results

```python
import json

# Load benchmark results
with open('results/benchmarks/m1_results.json', 'r') as f:
    results = json.load(f)

print(f"ISI Accuracy: {results['accuracy']:.1%}")
print(f"Lead Time: {results['lead_time_min']} minutes")
```

Note

This directory is gitignored. Large result files are not tracked in version control.
